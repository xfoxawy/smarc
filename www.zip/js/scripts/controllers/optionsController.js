smarc.controller('optionsController', ['$scope', function($scope){
    
}])
