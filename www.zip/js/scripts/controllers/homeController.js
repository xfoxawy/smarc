smarc.controller('homeController', ['$scope', function($scope){
    
}])
