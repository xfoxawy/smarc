smarc.controller('rootController', [
    '$scope',
    '$mdSidenav',
    'Room',
    'IO',
    '$http',
    function($scope, $mdSidenav, Room, IO, $http){
        $scope.incomeReq = "hello";
        $scope.tests = "test";
        IO.on('incomeReq', function(data){
            $scope.incomeReq = data;
        });

        $scope.test = function(){
            $http({
                method: "GET",
                url: "http://localhost:3050/test2"
            }).then(function(data){
                $scope.tests = data;
            });
        };

        $scope.rooms = Room.rooms;

        $scope.toggleSideBar = function(id) {
            if( $mdSidenav(id).isOpen() ) $scope.closeSidebar(id);
            else $scope.openSidebar(id);
        };
        $scope.openSidebar = function(id){
            $mdSidenav(id).open();
        };
        $scope.closeSidebar = function(id){
            $mdSidenav(id).close();
        };
    }
]);
