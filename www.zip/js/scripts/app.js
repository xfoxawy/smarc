var smarc = angular.module('Smarc', [
    'ngResource',
    'ngAria',
    'ngAnimate',
    'ngTouch',
    'ngRoute',
    'ngMaterial'
]);
